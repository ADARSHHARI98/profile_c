﻿using Microsoft.AspNetCore.Mvc;

namespace Profile.Controllers
{
    public class AoutCotroller : Controller
    {
        public IActionResult About()
        {
            return View();
        }
    }
}
