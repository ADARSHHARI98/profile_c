﻿using Microsoft.AspNetCore.Mvc;

namespace Profile.Controllers
{
    public class ConnectController : Controller
    {
        public IActionResult Connect()
        {
            return View();
        }
    }
}
