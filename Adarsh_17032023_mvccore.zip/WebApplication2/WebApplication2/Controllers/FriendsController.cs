﻿using Microsoft.AspNetCore.Mvc;

namespace Profile.Controllers
{
    public class FriendsController : Controller
    {
        public IActionResult Friends()
        {
            return View();
        }
    }
}
