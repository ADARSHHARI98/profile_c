﻿using Microsoft.AspNetCore.Mvc;

namespace Profile.Controllers
{
    public class ContactController : Controller
    {
        public IActionResult Contact()
        {
            return View();
        }
    }
}
