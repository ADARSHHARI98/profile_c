﻿using Microsoft.AspNetCore.Mvc;

namespace Profile.Controllers
{
    public class GallaryController : Controller
    {
        public IActionResult Gallary()
        {
            return View();
        }
    }
}
