﻿using Microsoft.AspNetCore.Mvc;

namespace Profile.Controllers
{
    public class ProjectsController : Controller
    {
        public IActionResult Project()
        {
            return View();
        }
    }
}
