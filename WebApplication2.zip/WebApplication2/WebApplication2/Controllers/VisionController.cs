﻿using Microsoft.AspNetCore.Mvc;

namespace Profile.Controllers
{
    public class VisionController : Controller
    {
        public IActionResult Vision()
        {
            return View();
        }
    }
}
